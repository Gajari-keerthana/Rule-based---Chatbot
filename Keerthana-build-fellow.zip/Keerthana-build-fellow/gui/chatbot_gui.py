import tkinter as tk
from tkinter import scrolledtext
from main import get_response

class ChatbotGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("EduBot - EdTech Chatbot")

        self.chat_log = scrolledtext.ScrolledText(root, state='disabled', width=60, height=20)
        self.chat_log.pack(padx=10, pady=10)

        self.entry = tk.Entry(root, font=("Arial", 14))
        self.entry.pack(fill=tk.X, padx=10)
        self.entry.bind("<Return>", self.send_message)

        self.send_button = tk.Button(root, text="Send", command=self.send_message)
        self.send_button.pack(pady=10)

        self.add_message("EduBot", "Hello! Ask me anything or type 'exit' to quit.")

    def add_message(self, sender, message):
        self.chat_log.config(state='normal')
        self.chat_log.insert(tk.END, f"{sender}: {message}\n")
        self.chat_log.config(state='disabled')
        self.chat_log.yview(tk.END)

    def send_message(self, event=None):
        user_input = self.entry.get().strip()
        if not user_input:
            return
        self.add_message("You", user_input)
        self.entry.delete(0, tk.END)
        if user_input.lower() in ['exit', 'quit']:
            self.add_message("EduBot", "Goodbye!")
            self.root.after(1000, self.root.quit)
        else:
            response = get_response(user_input)
            self.add_message("EduBot", response)

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatbotGUI(root)
    root.mainloop()
