import sys
import pandas as pd
import openai
from scripts.predict_intent import predict_intent

# ✅ Directly include OpenAI API key here (for demo/testing ONLY)
openai.api_key = "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"

# Load FAQ data and map intents to responses
faq_df = pd.read_csv("data/faq_data.csv")
intent_response_map = faq_df.groupby("intent")["response"].first().to_dict()

# LLM fallback function using OpenAI GPT
def llm_response(prompt):
    print("(Fallback to GPT)")
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # or "gpt-4"
        messages=[
            {"role": "system", "content": "You are a helpful EdTech chatbot."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7,
        max_tokens=150
    )
    return response.choices[0].message.content.strip()

# Main response function
def get_response(user_input):
    try:
        intent = predict_intent(user_input)
        response = intent_response_map.get(intent)
        if response:
            return response
        else:
            return llm_response(user_input)
    except:
        return llm_response(user_input)

# CLI chatbot
def run_cli():
    print("EduBot (Hybrid) is ready! Type 'exit' to quit.")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ['exit', 'quit']:
            print("EduBot: Goodbye!")
            break
        response = get_response(user_input)
        print("EduBot:", response)

# GUI support
def run_gui():
    from gui.chatbot_gui import ChatbotGUI
    import tkinter as tk

    root = tk.Tk()
    app = ChatbotGUI(root)
    root.mainloop()

# Entry point
if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "gui":
        run_gui()
    else:
        run_cli()
