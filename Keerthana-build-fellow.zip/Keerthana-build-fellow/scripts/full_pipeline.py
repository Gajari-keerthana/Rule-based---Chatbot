import os
import pandas as pd
import numpy as np
import re
import pickle
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout

# --- Step 1: Load Data ---
df = pd.read_csv("data/faq_data.csv")

# --- Step 2: Preprocess Text ---
def preprocess(text):
    text = text.lower()
    text = re.sub(r"[^\w\s]", "", text)
    return text.strip()

df["question"] = df["question"].apply(preprocess)

# --- Step 3: Encode Labels ---
label_encoder = LabelEncoder()
df["label"] = label_encoder.fit_transform(df["intent"])
num_classes = len(label_encoder.classes_)

# --- Step 4: Tokenization ---
tokenizer = Tokenizer()
tokenizer.fit_on_texts(df["question"])
sequences = tokenizer.texts_to_sequences(df["question"])

max_len = max(len(seq) for seq in sequences)
X = pad_sequences(sequences, maxlen=max_len)
y = tf.keras.utils.to_categorical(df["label"], num_classes=num_classes)

# --- Step 5: Train-Test Split ---
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# --- Step 6: Create Model ---
model = Sequential([
    Embedding(input_dim=len(tokenizer.word_index) + 1, output_dim=64, input_length=max_len),
    LSTM(64),
    Dropout(0.5),
    Dense(32, activation='relu'),
    Dense(num_classes, activation='softmax')
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# --- Step 7: Train Model ---
print("Training model...")
model.fit(X_train, y_train, epochs=30, batch_size=8, validation_split=0.1, verbose=1)

# --- Step 8: Evaluate Model ---
loss, acc = model.evaluate(X_test, y_test, verbose=0)
print(f"\nTest Loss: {loss:.4f}, Test Accuracy: {acc:.4f}")

# --- Step 9: Save Model and Preprocessing Tools ---
os.makedirs("models", exist_ok=True)
model.save("models/edtech_chatbot_model.h5")
with open("models/tokenizer.pkl", "wb") as f:
    pickle.dump(tokenizer, f)
with open("models/label_encoder.pkl", "wb") as f:
    pickle.dump(label_encoder, f)
print("Model and preprocessing tools saved to /models.")

# --- Step 10: Predict on a New Input ---
def predict(question):
    question = preprocess(question)
    seq = tokenizer.texts_to_sequences([question])
    padded = pad_sequences(seq, maxlen=max_len)
    pred = model.predict(padded)
    label_index = np.argmax(pred)
    return label_encoder.inverse_transform([label_index])[0]

# Sample prediction
sample_question = "how to reset password"
predicted_intent = predict(sample_question)
print(f"\nSample Prediction:\nInput: \"{sample_question}\"\nPredicted Intent: {predicted_intent}")
